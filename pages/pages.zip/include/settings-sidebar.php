 <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
   
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      

      
      
      <!-- /.tab-pane -->
    </div>
  </aside>