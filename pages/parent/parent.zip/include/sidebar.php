  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      
      
      <!-- sidebar menu: style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active ">
          <a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard </a>
        
        </li>
        
        <li>
          <a href="email_inbox.php">
            <i class="fa fa-envelope-open"></i> <span>Email</span>
           
          </a>
        </li>
        
      
        
        
         <li>
          <a href="children.php">
            <i class="fa fa-graduation-cap"></i> <span>Children</span>
           
          </a>
        </li>
        
         <li>
          <a href="notification.php">
            <i class="fa fa-bell-o"></i> <span>Notification</span>
           
          </a>
        </li>
         <li>
          <a href="dashboard3.php ">
            <i class="fa fa-bell-o"></i> <span>dashboard2</span>
           
          </a>
        </li>
        
        <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Finance</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            
            <li><a href="invoice.php"><i class="fa fa-circle-o"></i> Invoices</a></li>
            <!--<li><a href="fee.php"><i class="fa fa-circle-o"></i>Fees</a></li>-->
            <li><a href="transaction.php"><i class="fa fa-circle-o"></i>Payment</a></li>
            
            
          </ul>
        </li>
       
        
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>